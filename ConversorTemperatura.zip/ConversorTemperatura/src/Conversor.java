public class Conversor {


    public static double convertFahrenheitToCelsius(double valorFahrenheit) {
        double result;
        result = (valorFahrenheit - 32) / 1.8;
        return result;
    }

    public static double convertCelsiusToKelvin(double valorCelsius){
        double result;
        result = valorCelsius + 273.15;
        return result;
    }

    public static double convertCelsiusToFahrenheit(double valorCelsius) {
        double result;
        result = (valorCelsius * 1.8) + 32;
        return result;
    }


    public static double convertKmToMilhasHora(double valorKmHora) {
        double result;
        result = valorKmHora / 1.61;
        return result;
    }


    public static double convertMilhasToKmHora(double valorMilhasHora) {
        double result;
        result = valorMilhasHora * 1.61;
        return result;
    }

    public static double convertKmToMetrosPorSegundo(double valorKmHora) {
        double result;
        result = valorKmHora * 0.911;
        return result;
    }

    public static double convertMetroToKm(double valorMetro) {
        double result;
        result = valorMetro / 1000;
        return result;
    }

    public static double convertMetroToCentimetro(double valorMetro) {
        double result;
        result = valorMetro * 100;
        return result;
    }

    public static double convertMetroToMilimetro(double valorMetro) {
        double result;
        result = valorMetro * 1000;
        return result;
    }

    public static double convertHoraToMinutos(double valorHora) {
        double result;
        result = valorHora * 60;
        return result;
    }

    public static double convertHoraToSegundos(double valorHora) {
        double result;
        result = valorHora * 3600;
        return result;
    }

    public static double convertHoraToDia(double valorHora) {
        double result;
        result = valorHora / 24;
        return result;
    }
}
