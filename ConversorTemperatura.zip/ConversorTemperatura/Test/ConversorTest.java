import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ConversorTest {

    @Test
    public void testConversorTemperatura(){
        double valorCelsius = 30;
        double valorFahrenheit = 50;

        double resultCelsius = Conversor.convertFahrenheitToCelsius(valorFahrenheit);
        double resultKelvin = Conversor.convertCelsiusToKelvin(valorCelsius);
        double resultFahrenheit = Conversor.convertCelsiusToFahrenheit(valorCelsius);

        assertEquals(303.15, resultKelvin,0.01);
        assertEquals(86, resultFahrenheit,0.01);
        assertEquals(10, resultCelsius,0.01);
    }


    @Test
    public void testConversorVelocidade(){
        double valorKmHora = 10;
        double valorMilhasHora = 3;

        double resultMilhasHora = Conversor.convertKmToMilhasHora(valorKmHora);
        double resultKmHora = Conversor.convertMilhasToKmHora(valorMilhasHora);
        double resultMetrosPorSegundo = Conversor.convertKmToMetrosPorSegundo(valorKmHora);

        assertEquals(6.21, resultMilhasHora,0.01);
        assertEquals(4.83, resultKmHora,0.01);
        assertEquals(9.11, resultMetrosPorSegundo,0.01);
    }

    @Test
    public void testConversorDistancia(){
        double valorMetro = 1;

        double resultKm = Conversor.convertMetroToKm(valorMetro);
        double resultCentimetro = Conversor.convertMetroToCentimetro(valorMetro);
        double resultMilimetro = Conversor.convertMetroToMilimetro(valorMetro);

        assertEquals(0.001, resultKm,0.01);
        assertEquals(100, resultCentimetro,0.01);
        assertEquals(1000, resultMilimetro,0.01);
    }


    @Test
    public void testConversorTempo(){
        double valorHora = 1;

        double resultMinuto = Conversor.convertHoraToMinutos(valorHora);
        double resultSegundo = Conversor.convertHoraToSegundos(valorHora);
        double resultDia = Conversor.convertHoraToDia(valorHora);

        assertEquals(60, resultMinuto,0.01);
        assertEquals(3600, resultSegundo,0.01);
        assertEquals(0.04, resultDia,0.01);
    }

}
